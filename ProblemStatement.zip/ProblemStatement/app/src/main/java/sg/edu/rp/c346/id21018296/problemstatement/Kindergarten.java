package sg.edu.rp.c346.id21018296.problemstatement;

public class Kindergarten {
    private String enrolment;
    private String year;

    public Kindergarten(String enrolment, String year) {
        this.enrolment = enrolment;
        this.year = year;
    }

    public String getEnrolment() {
        return enrolment;
    }

    public void setEnrolment(String enrolment) {
        this.enrolment = enrolment;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "Kindergarten{" +
                "enrolment=" + enrolment +
                ", year=" + year +
                '}';
    }
}
